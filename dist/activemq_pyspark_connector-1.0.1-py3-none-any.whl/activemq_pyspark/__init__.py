# src/activemq_pyspark/__init__.py
from .datasource import ActiveMQDataSource
